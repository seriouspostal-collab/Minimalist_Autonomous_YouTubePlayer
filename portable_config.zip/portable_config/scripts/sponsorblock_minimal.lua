local mp = require('mp')
local utils = require('mp.utils')

-- НАСТРОЙКИ КАТЕГОРИЙ (true - пропускать, false - игнорировать)
local categories_config = {
    intro = true,          -- Начальные титры / вступление
    outro = true,          -- Конечные титры / заставки
    music_offtopic = true  -- Болтовня / вставки без музыки в клипах
}

local current_segments = {}
local fetched_video_id = nil

-- Функция получения ID видео
local function get_video_id()
    local path = mp.get_property("path", "")
    local purl = mp.get_property("metadata/by-key/PURL", "")
    local ytdl_id = mp.get_property("ytdl-metadata/id", "")
    
    if ytdl_id ~= "" then return ytdl_id end

    local urls = {
        "youtu%.be/([%w-_]+)",
        "v=([%w-_]+)",
        "embed/([%w-_]+)"
    }
    for _, u in ipairs(urls) do
        local id = path:match(u) or purl:match(u)
        if id then return id end
    end
    return nil
end

-- Проверка позиции во время воспроизведения (вызывается только при смене времени)
local function skip_ads(name, pos)
    if not pos or #current_segments == 0 then return end
    for _, seg in ipairs(current_segments) do
        if pos >= seg.start and pos < seg.ending - 0.01 then
            mp.set_property("time-pos", seg.ending + 0.01)
            mp.osd_message(string.format("⏩ Пропущено (%s)", seg.category), 2)
            break
        end
    end
end

-- Запрос к API SponsorBlock через прямой вызов curl
local function fetch_segments(video_id)
    if not video_id or video_id == fetched_video_id then return end
    fetched_video_id = video_id
    current_segments = {}

    -- Собираем только те категории, которые включены в настройках выше
    local active_cats = {}
    for cat, enabled in pairs(categories_config) do
        if enabled then table.insert(active_cats, cat) end
    end
    if #active_cats == 0 then return end

    local cats_json = utils.format_json(active_cats)

    -- Вызываем curl напрямую (без PowerShell, мгновенно и без нагрузки)
    local res = utils.subprocess({
        args = {
            "curl", "-s", "-G",
            "https://sponsor.ajay.app/api/skipSegments",
            "--data-urlencode", "videoID=" .. video_id,
            "--data-urlencode", "categories=" .. cats_json
        }
    })

    if res.status ~= 0 or not res.stdout then return end

    -- Надежный парсинг JSON с помощью встроенных средств mpv
    local json = utils.parse_json(res.stdout)
    if type(json) == "table" then
        for _, item in ipairs(json) do
            if item.segment and item.category and categories_config[item.category] then
                table.insert(current_segments, {
                    start = item.segment[1],
                    ending = item.segment[2],
                    category = item.category
                })
            end
        end
    end

    if #current_segments > 0 then
        mp.osd_message("SponsorBlock: загружено сегментов: " .. #current_segments, 2)
        -- Включаем отслеживание таймлайна только если есть что пропускать
        mp.observe_property("time-pos", "native", skip_ads)
    end
end

-- Сброс и инициализация при загрузке нового видео
mp.register_event("file-loaded", function()
    fetched_video_id = nil
    current_segments = {}
    mp.unobserve_property(skip_ads)
    
    mp.add_timeout(1.0, function()
        local id = get_video_id()
        if id then
            fetch_segments(id)
        end
    end)
end)