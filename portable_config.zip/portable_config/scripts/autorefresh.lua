-- autorefresh.lua for mpv
-- Позволяет обновлять плейлист на лету по горячей клавише или событию

local mp = require 'mp'

-- Функция обновления плейлиста
function refresh_playlist()
    mp.msg.info("Обновление плейлиста...")
    -- Перезагружаем текущий элемент/плейлист с сохранением позиции
    mp.command("script-message uosc-flash-message \"Обновление плейлиста...\"")
    mp.command("loadfile ${path} append-or-play") -- или аналог перезапроса yt-dlp
end

-- Регистрируем команду, которую можно повесить на горячую клавишу
mp.register_script_message("refresh-playlist", refresh_playlist)

-- Привязываем горячую клавишу 'r' для обновления в input.conf или прямо здесь
mp.add_key_binding("r", "manual-refresh", refresh_playlist)